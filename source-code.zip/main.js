/* eslint-disable radix */
/**
 * This template is a production ready boilerplate for developing with `CheerioCrawler`.
 * Use this to bootstrap your projects using the most up-to-date code.
 * If you're looking for examples or want to learn more, see README.
 */

const Apify = require('apify');
const { wordsToNumbers } = require('words-to-numbers');

const { utils: { log } } = Apify;

Apify.main(async () => {
    const { startUrls } = await Apify.getInput();

    const requestList = await Apify.openRequestList('start-urls', startUrls);
    const proxyConfiguration = await Apify.createProxyConfiguration();

    const crawler = new Apify.CheerioCrawler({
        requestList,
        proxyConfiguration,
        // Be nice to the websites.
        // Remove to unleash full power.
        maxConcurrency: 1,
        handlePageFunction: async (context) => {
            const { url, userData: { label } } = context.request;
            const { $ } = context;
            log.info('Page opened.', { label, url });
            const text = $('div.inspection-summary p').text();
            
            //test
            //const text = 'sdfsd 4f5sdf4s56df4 6sdf 4 people dfsdtssd first people twenty two people 546 people  two hundred people people adasd people';
            const matchPeople = text.match(/\d+ people/g);
            const matchNumber = context.request.url.match(/\d-\d+/);
            if (!matchNumber.length) throw new Error('url does not contain x-xxxxxxxxxx number');
            const tenDigitNumber = parseInt(matchNumber[0].split('-')[1]);

            // numeral
            for (const match of matchPeople) {
                const result = {};
                result.tenDigitNumber = tenDigitNumber;
                result.people = parseInt(match);
                await Apify.pushData(result);
            }

            // words
            const matchWords = text.match(/[^ ]+ [^ ]+ people/g).map((x)=> x.replace(' people', ''));
            
            for (const prefix of matchWords) {
                let number = wordsToNumbers(prefix);
                if (Number.isInteger(number)) {
                    const result = {};
                    result.tenDigitNumber = tenDigitNumber;
                    result.people = number;
                    await Apify.pushData(result);
                } else {
                    number = wordsToNumbers(prefix.split(' ')[1]);
                    if (Number.isInteger(number)) {
                        const result = {};
                        result.tenDigitNumber = tenDigitNumber;
                        result.people = number;
                        await Apify.pushData(result);
                    }
                }
            }
        },
    });

    log.info('Starting the crawl.');
    await crawler.run();
    log.info('Crawl finished.');
});
